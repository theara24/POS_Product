﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_Product
{
    public partial class PaymentForm : Form
    {
        public PaymentForm()
        {
            InitializeComponent();
            txtTotalAmount.Text = TotalAmount.ToString("c2");
            comboDiscount.SelectedIndex = 1;
        }
        public double TotalAmount { get; set; } = MyData.TotalAmount;

        public double Discount { get; set; }
        public double DiscountPrice { get; set; }
        public double Payment { get; set; }
        public double CashReviewed { get; set; }
        public double CashReturned { get; set; }
        private double[] dicount = { 0, 5, 10, 15, 20 };

        private void PaymentForm_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void floatBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void comboDiscount_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboDiscount.SelectedIndex;
            Discount = dicount[index];
            DiscountPrice = TotalAmount * Discount / 100;
            Payment = TotalAmount - DiscountPrice;

            txtDiscountPrice.Text = DiscountPrice.ToString("c2");
            txtPayment.Text = Payment.ToString("c2");

            if(CashReviewed > 0)
            {
                txtCashReceived_KeyUp(null, null);
            }
        }

        private void txtCashReceived_KeyUp(object sender, KeyEventArgs e)
        {
            string text = txtCashReceived.Text;
            if (text.Length > 0)
            {
                CashReviewed = double.Parse(text);
                CashReturned = CashReviewed - Payment;

                txtCashReturned.Text = CashReturned.ToString("$#,##0.00");
                txtCashReturned.ForeColor = Color.White;
                if(CashReturned < 0)
                {
                    txtCashReturned.BackColor = Color.Red;
                    btnPayment.Enabled = false;
                }
                else
                {
                    txtCashReturned.BackColor = Color.Green;
                    btnPayment.Enabled = true;

                    if (e != null)
                    {
                       if (e.KeyCode == Keys.Enter)
                        {
                            btnPayment_Click(null, null);
                        }
                    }
                }
            }
            else
            {
                txtCashReturned.Text = "";
                txtCashReceived.BackColor = Color.White;
                btnPayment.Enabled= false;
            }
        }

        private void btnPayment_Click(object value1, object value2)
        {
            throw new NotImplementedException();
        }

        private void txtCashReceived_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCashReturned_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnPayment_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
        }
    }
}
