﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.IO;

namespace POS_Product
{
    internal class MyData
    {
        public static HashSet<ProductControl> Orders {  get; set; } = new HashSet<ProductControl>();
        public static double TotalAmount { get => Orders.Sum(p => p.Amount); }
        public static ToolStripMenuItem MShowOrderDetail { get; internal set; }
        public static ToolStripMenuItem MPayment { get; internal set; }

        internal static void LoadPProducts(TableLayoutPanel tableLayoutPanel)
        {
            string[] files = Directory.GetFiles("D:\\1 Theara\\1,University\\1,SETEC\\Year2\\ឆមាស១\\C#\\WindowForm\\POS_Product\\Image");

            int r = 0, c = 1;
            int id = 1;
            Random rnd = new Random();
            foreach (string file in files) 
            { 
                if (!file.ToLower().EndsWith(".jpg"))
               {
                    continue; 
                }

                Image img = Image.FromFile(file);
                string pname = Path.GetFileNameWithoutExtension(file);
                double price = rnd.Next(10, 30);
                ProductControl p = new ProductControl()
                {
                    Id = id++,
                    Picture = img,
                    PName = pname,
                    Price = price
                };

                tableLayoutPanel.Controls.Add(p, c , r);
                c++;
                if ( c > 4)
                {
                    c = 1;
                    r++;
                }
            }
        }

        internal static void ShowOrderDetail(DataGridView dataGridView, TextBox txtTotalAmount)
        {
            foreach (ProductControl p in Orders)
            {
                dataGridView.Rows.Add($"{p.Id:000}",p.PName,$"{p.Price:c2}",p.Qty,$"{p.Amount:c2}");
                txtTotalAmount.Text = $"{TotalAmount:c2}";
            }
            
        }
    }

}
