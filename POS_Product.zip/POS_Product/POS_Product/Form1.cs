﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POS_Product
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            MyData.MShowOrderDetail = mShowOrderDetail;
            MyData.MPayment = mPayment;

            MyData.LoadPProducts(tableLayoutPanel);
        }

        private void productControl1_Load(object sender, EventArgs e)
        {

        }

        private void productControl1_Load_1(object sender, EventArgs e)
        {

        }

        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void mShowOrderDetail_Click(object sender, EventArgs e)
        {
            new ShowOrderDetailForm().ShowDialog(this);
        }

        private PaymentForm paymentForm;
        private void mPayment_Click(object sender, EventArgs e)
        {
            paymentForm = new PaymentForm();
            var result = paymentForm.ShowDialog(this);
            if (result == DialogResult.OK)
            {
                MyData.Orders.Clear();
                Application.Restart();
            }
        }

        private void mReload_Click(object sender, EventArgs e)
        {
            if (MyData.Orders.Count > 0) 
            { 
                var result = MessageBox.
                    Show("Are you sure to cancel the order?", 
                    "Warning", MessageBoxButtons.YesNo, 
                    MessageBoxIcon.Question);
                if (result == DialogResult.Yes) 
                {
                    MyData.Orders.Clear();
                    Application.Restart();
                }

            }
            else
            {
                MyData.Orders.Clear();
                Application.Restart();
            }
        }

        private void mExit_Click(object sender, EventArgs e)
        {
            if (MyData.Orders.Count > 0)
            {
                var result = MessageBox.
                    Show("Are you sure to exit the order?",
                    "Warning", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    MyData.Orders.Clear();
                    Application.Exit();
                }
            }
            else
            {
                MyData.Orders.Clear();
                Application.Exit();
            }
        }
    }
}
